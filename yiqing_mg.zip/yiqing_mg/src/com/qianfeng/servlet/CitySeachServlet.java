package com.qianfeng.servlet;

import java.math.BigDecimal;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qianfeng.biz.CityBIZ;
import com.qianfeng.bizimpl.CityBIZImpl;
import com.qianfeng.entity.City;
import com.qianfeng.vo.PageVO;

public class CitySeachServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		String cityname = null;
		try {
			cityname = new String(request.getParameter("cityname").getBytes(
					"iso-8859-1"), "utf-8");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		String infectcount = request.getParameter("count");
		CityBIZ cityBIZ = new CityBIZImpl();
		PageVO<List<City>> pageVO = new PageVO<List<City>>();
		try {
			List<City> cityList = cityBIZ.searchUser(cityname, infectcount);
			pageVO.setData(cityList);
			pageVO.setPageIndex(new BigDecimal(1));
			pageVO.setPageCount(new BigDecimal(cityList.size()));
			pageVO.setTotalCount(new BigDecimal(cityList.size()));
			pageVO.setEndPage(new BigDecimal(1));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		request.setAttribute("pageVO", pageVO);
		try {
			request.getRequestDispatcher("COVID-19MapDataGrid.jsp").forward(
					request, response);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
