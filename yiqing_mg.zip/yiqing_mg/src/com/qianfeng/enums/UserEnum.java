package com.qianfeng.enums;

public enum UserEnum {
	LOGIN_SUCCESS("LOGIN_SUCCESS", "登录成功"), LOGIN_FAIL("LOGIN_FAIL", "登陆失败"), USERNAME_IS_EMPTY(
			"USERNAME_IS_EMPTY", "用户名为空"), PASSWORD_IS_EMPTY(
			"PASSWORD_IS_EMPTY", "密码为空"), EMAIL_IS_EMPTY("EMAIL_IS_EMPTY",
			"邮箱为空"), USERNAME_OR_PASSWORD_FAIL("USERNAME_OR_PASSWORD_FAIL",
			"用户名或密码错误"), VALIDATE_CODE_IS_FAIL("VALIDATE_CODE_IS_FAIL", "验证码错误"), UPDATE_SUCCESS(
			"UPDATE_SUCCESS", "修改成功"), UPDATE_FAIL("UPDATE_FAIL", "修改失败");

	private String value;
	private String desc;

	private UserEnum(String value, String desc) {
		this.value = value;
		this.desc = desc;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

}
