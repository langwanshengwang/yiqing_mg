package com.qianfeng.servlet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qianfeng.biz.UserBIZ;
import com.qianfeng.bizimpl.UserBIZImpl;
import com.qianfeng.enums.UserEnum;

public class UserLoginServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		String email = request.getParameter("email");
		String password = request.getParameter("pwd");
		String validateCode = request.getParameter("validatecode");
		UserBIZ userBIZ = new UserBIZImpl();
		String result = null;
		try {
			String syscode = (String) request.getSession().getAttribute(
					"syscode");
			result = userBIZ.login(email, password, validateCode, syscode,
					request);

		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			if (result.equals(UserEnum.LOGIN_SUCCESS.getValue())) {
				request.getRequestDispatcher("index.jsp").forward(request,
						response);
			} else {
				request.getRequestDispatcher("login.jsp?msg=" + request + "")
						.forward(request, response);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
