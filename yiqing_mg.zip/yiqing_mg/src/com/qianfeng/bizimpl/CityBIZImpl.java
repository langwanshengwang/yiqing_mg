package com.qianfeng.bizimpl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.qianfeng.biz.CityBIZ;
import com.qianfeng.dao.CityDAO;
import com.qianfeng.daoimpl.CityDAOImpl;
import com.qianfeng.entity.City;

public class CityBIZImpl implements CityBIZ {

	CityDAO cityDAO = new CityDAOImpl();

	@Override
	public void save(City transientInstance) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(City persistentInstance) {
		// TODO Auto-generated method stub

	}

	@Override
	public City findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findByExample(City instance) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findByProperty(String propertyName, Object value) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findByCityId(Object cityId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findByCity(Object city) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findByFatherId(Object fatherId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findByInfectCount(Object infectCount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public City merge(City detachedInstance) {
		// TODO Auto-generated method stub
		City city = cityDAO.findById(detachedInstance.getId());
		city.setInfectCount(detachedInstance.getInfectCount());
		return cityDAO.merge(city);
	}

	@Override
	public void attachDirty(City instance) {
		// TODO Auto-generated method stub

	}

	@Override
	public void attachClean(City instance) {
		// TODO Auto-generated method stub

	}

	@Override
	public BigDecimal getTotalCount() {
		// TODO Auto-generated method stub
		return cityDAO.getTotalCount();
	}

	@Override
	public List<City> findUserListByPage(BigDecimal pageIndex,
			BigDecimal pageCount) {
		// TODO Auto-generated method stub
		BigDecimal beginPageCount = pageIndex.subtract(new BigDecimal(1))
				.multiply(pageCount);
		return cityDAO.findUserListByPage(beginPageCount, pageCount);
	}

	@Override
	public List<City> searchUser(String cityname, String infectcount) {
		// TODO Auto-generated method stub
		StringBuilder hql = new StringBuilder("from City as ct where 1=1");
		Map<String, Object> param = new HashMap<String, Object>();
		if (cityname != null && !cityname.equals("")) {
			hql.append(" and ct.city like :city");
			param.put("city", "%" + cityname + "%");
		}
		if (infectcount != null && !infectcount.equals("")) {
			hql.append(" and ct.infectCount >= :infectCount");
			System.out.println(Integer.parseInt(infectcount) + "/*/*/*/*/");
			param.put("infectCount", Integer.parseInt(infectcount));
		}
		return cityDAO.searchCity(hql.toString(), param);
	}

}
