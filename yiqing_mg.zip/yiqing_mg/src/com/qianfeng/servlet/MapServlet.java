package com.qianfeng.servlet;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;
import com.qianfeng.biz.ProvinceBIZ;
import com.qianfeng.bizimpl.ProvinceBIZImpl;
import com.qianfeng.entity.JsonRootBean;

public class MapServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		response.setCharacterEncoding("utf-8");
		response.setHeader("Content-Type", "text/plain;charset=utf-8");

		List<JsonRootBean> jsonRootBeans = new ArrayList<JsonRootBean>();

		ProvinceBIZ provinceBIZ = new ProvinceBIZImpl();

		try {
			jsonRootBeans = provinceBIZ.findAll();
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}

		try {
			response.getWriter().print(

			JSONObject.toJSONString(jsonRootBeans));
		} catch (Exception e) {
			// TODO: handle exception
		}

		// List<Cities> citiesList = new ArrayList<Cities>();
		// List<Cities> citiesList2 = new ArrayList<Cities>();
		//
		// JsonRootBean jsonRootBean = new JsonRootBean();
		// JsonRootBean jsonRootBean2 = new JsonRootBean();
		//
		// jsonRootBean.setProvinceName("广东");
		// jsonRootBean.setProvinceShortName("广东");
		// jsonRootBean.setConfirmedCount(50);
		//
		// Cities cities = new Cities();
		// cities.setCityName("深圳");
		// cities.setConfirmedCount(25);
		// Cities cities2 = new Cities();
		// cities2.setCityName("广州");
		// cities2.setConfirmedCount(25);
		//
		// citiesList.add(cities);
		// citiesList.add(cities2);
		// jsonRootBean.setCities(citiesList);
		//
		// jsonRootBean2.setProvinceName("广西");
		// jsonRootBean2.setProvinceShortName("广西");
		// jsonRootBean2.setConfirmedCount(100);
		//
		// Cities cities3 = new Cities();
		// cities3.setCityName("柳州");
		// cities3.setConfirmedCount(50);
		// Cities cities4 = new Cities();
		// cities4.setCityName("桂林");
		// cities4.setConfirmedCount(50);
		//
		// citiesList2.add(cities3);
		// citiesList2.add(cities4);
		// jsonRootBean2.setCities(citiesList2);
		//
		// jsonRootBeans.add(jsonRootBean);
		// jsonRootBeans.add(jsonRootBean2);

	}
}
