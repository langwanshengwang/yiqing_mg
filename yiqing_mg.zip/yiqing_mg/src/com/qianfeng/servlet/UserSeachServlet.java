package com.qianfeng.servlet;

import java.math.BigDecimal;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qianfeng.biz.UserBIZ;
import com.qianfeng.bizimpl.UserBIZImpl;
import com.qianfeng.entity.User;
import com.qianfeng.vo.PageVO;

public class UserSeachServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		String username = null;
		try {
			username = new String(request.getParameter("username").getBytes(
					"iso-8859-1"), "utf-8");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		String email = request.getParameter("email");
		UserBIZ userBIZ = new UserBIZImpl();
		PageVO<List<User>> pageVO = new PageVO<List<User>>();
		try {
			List<User> userList = userBIZ.searchUser(username, email);
			pageVO.setData(userList);
			pageVO.setPageIndex(new BigDecimal(1));
			pageVO.setPageCount(new BigDecimal(userList.size()));
			pageVO.setTotalCount(new BigDecimal(userList.size()));
			pageVO.setEndPage(new BigDecimal(1));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		request.setAttribute("pageVO", pageVO);
		try {
			request.getRequestDispatcher("userList.jsp").forward(request,
					response);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
