package com.qianfeng.bizimpl;

import java.util.ArrayList;
import java.util.List;

import com.qianfeng.biz.ProvinceBIZ;
import com.qianfeng.dao.ProvinceDAO;
import com.qianfeng.daoimpl.ProvinceDAOImpl;
import com.qianfeng.entity.Cities;
import com.qianfeng.entity.City;
import com.qianfeng.entity.JsonRootBean;
import com.qianfeng.entity.Province;

public class ProvinceBIZImpl implements ProvinceBIZ {
	ProvinceDAO provinceDAO = new ProvinceDAOImpl();

	@Override
	public void save(Province transientInstance) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(Province persistentInstance) {
		// TODO Auto-generated method stub

	}

	@Override
	public Province findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findByExample(Province instance) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findByProperty(String propertyName, Object value) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findByProvince(Object province) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findAll() {
		List<JsonRootBean> jsonRootBeanList = new ArrayList<JsonRootBean>();
		List<Province> provinceList = provinceDAO.findAll();
		for (Province province : provinceList) {
			JsonRootBean jsonRootBean = new JsonRootBean();
			List<Cities> citiesList = new ArrayList<Cities>();
			int count = 0;
			jsonRootBean.setProvinceName(province.getProvince());
			jsonRootBean.setProvinceShortName(province.getProvince());
			for (City city : province.getCities()) {
				Cities cities = new Cities();
				cities.setCityName(city.getCity());
				cities.setConfirmedCount(city.getInfectCount());
				count += city.getInfectCount();
			}
			jsonRootBean.setConfirmedCount(count);
			jsonRootBean.setCities(citiesList);
			jsonRootBeanList.add(jsonRootBean);
		}
		return jsonRootBeanList;
	}

	@Override
	public Province merge(Province detachedInstance) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void attachDirty(Province instance) {
		// TODO Auto-generated method stub

	}

	@Override
	public void attachClean(Province instance) {
		// TODO Auto-generated method stub

	}

}
