package com.qianfeng.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.qianfeng.entity.User;

public interface UserDAO {

	void save(User transientInstance);

	void delete(User persistentInstance);

	User findById(java.lang.Integer id);

	List findByExample(User instance);

	List findByProperty(String propertyName, Object value);

	List findByUsername(Object username);

	List findByPassword(Object password);

	List findByEamil(Object eamil);

	List findAll();

	User merge(User detachedInstance);

	void attachDirty(User instance);

	void attachClean(User instance);

	User login(String email, String password);

	BigDecimal getTotalCount();

	List<User> findUserListByPage(BigDecimal beginPageCount,
			BigDecimal pageCount);

	void update(User user);

	List<User> searchUser(String hql, Map<String, Object> user);
}