package com.qianfeng.biz;

import java.math.BigDecimal;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qianfeng.entity.User;

public interface UserBIZ {

	void save(User transientInstance);

	void delete(User persistentInstance, HttpServletRequest request)
			throws Exception;

	User findById(java.lang.Integer id);

	List findByExample(User instance);

	List findByProperty(String propertyName, Object value);

	List findByUsername(Object username);

	List findByPassword(Object password);

	List findByEamil(Object eamil);

	List findAll();

	User merge(User detachedInstance);

	void attachDirty(User instance);

	void attachClean(User instance);

	String login(String email, String password, String valitCode,
			String sysCode, HttpServletRequest request);

	BigDecimal getTotalCount();

	List<User> findUserListByPage(BigDecimal pageIndex, BigDecimal pageCount);

	String update(HttpServletRequest request, HttpServletResponse response,
			ServletConfig servletConfig);

	List<User> searchUser(String username, String email);
}