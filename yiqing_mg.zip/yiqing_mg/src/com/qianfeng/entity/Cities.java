/**
 * Copyright 2022 bejson.com 
 */
package com.qianfeng.entity;

/**
 * Auto-generated: 2022-07-06 14:13:37
 * 
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Cities {

	private String cityName;
	private int confirmedCount;
	private int suspectedCount;
	private int curedCount;
	private int deadCount;
	private long locationId;

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getCityName() {
		return cityName;
	}

	public void setConfirmedCount(int confirmedCount) {
		this.confirmedCount = confirmedCount;
	}

	public int getConfirmedCount() {
		return confirmedCount;
	}

	public void setSuspectedCount(int suspectedCount) {
		this.suspectedCount = suspectedCount;
	}

	public int getSuspectedCount() {
		return suspectedCount;
	}

	public void setCuredCount(int curedCount) {
		this.curedCount = curedCount;
	}

	public int getCuredCount() {
		return curedCount;
	}

	public void setDeadCount(int deadCount) {
		this.deadCount = deadCount;
	}

	public int getDeadCount() {
		return deadCount;
	}

	public void setLocationId(long locationId) {
		this.locationId = locationId;
	}

	public long getLocationId() {
		return locationId;
	}

}