package com.qianfeng.servlet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qianfeng.biz.UserBIZ;
import com.qianfeng.bizimpl.UserBIZImpl;
import com.qianfeng.enums.UserEnum;

public class UserUpdateServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		response.setCharacterEncoding("UTF-8");
		response.setHeader("Content-Type", "text/html;charset=UTF-8");
		UserBIZ userBIZ = new UserBIZImpl();
		String username = request.getParameter("username");
		try {
			String result = userBIZ.update(request, response,
					getServletConfig());
			System.out.println(result);
			if (result.equals(UserEnum.UPDATE_SUCCESS.getValue())) {
				response.sendRedirect("UserListByPageServlet?pageindex="
						+ request.getParameter("pageindex") + "&msg=" + result
						+ "");
			} else {
				response.sendRedirect("userUpdate.jsp?msg=" + result
						+ "&pageindex=" + request.getParameter("pageindex")
						+ "&userid=" + request.getParameter("userid")
						+ "&username=" + request.getParameter("uaername")
						+ "&password=" + request.getParameter("password")
						+ "&email=" + request.getParameter("email")
						+ "&iamgepath=" + request.getParameter("iamgepath")
						+ "");
			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}

}
