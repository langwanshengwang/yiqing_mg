package com.qianfeng.test;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;
import java.util.ListIterator;

import com.qianfeng.dao.UserDAO;
import com.qianfeng.daoimpl.UserDAOImpl;
import com.qianfeng.entity.User;

public class HelloWorld {
	public static void main(String[] args) {
		UserDAO userDAO = new UserDAOImpl();
		User user = new User();
		user.setEmail("1740582484@qq.com");
		user.setUsername("王超");
		user.setPassword("123456789");
		user.setCreatetime(new Timestamp(System.currentTimeMillis()));
		user.setUpdatetime(new Timestamp(System.currentTimeMillis()));
		userDAO.save(user);
		java.util.List<User> list = new java.util.List<User>() {

			@Override
			public <T> T[] toArray(T[] a) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object[] toArray() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public java.util.List<User> subList(int fromIndex, int toIndex) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public int size() {
				// TODO Auto-generated method stub
				return 0;
			}

			@Override
			public User set(int index, User element) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public boolean retainAll(Collection<?> c) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean removeAll(Collection<?> c) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public User remove(int index) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public boolean remove(Object o) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public ListIterator<User> listIterator(int index) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public ListIterator<User> listIterator() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public int lastIndexOf(Object o) {
				// TODO Auto-generated method stub
				return 0;
			}

			@Override
			public Iterator<User> iterator() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public boolean isEmpty() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public int indexOf(Object o) {
				// TODO Auto-generated method stub
				return 0;
			}

			@Override
			public User get(int index) {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public boolean containsAll(Collection<?> c) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean contains(Object o) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public void clear() {
				// TODO Auto-generated method stub

			}

			@Override
			public boolean addAll(int index, Collection<? extends User> c) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean addAll(Collection<? extends User> c) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public void add(int index, User element) {
				// TODO Auto-generated method stub

			}

			@Override
			public boolean add(User e) {
				// TODO Auto-generated method stub
				return false;
			}
		};
		list = userDAO.findAll();
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).getUsername()
					+ list.get(i).getEmail() + list.get(i).getPassword());
		}
	}
}
