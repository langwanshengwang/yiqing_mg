package com.qianfeng.servlet;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qianfeng.biz.UserBIZ;
import com.qianfeng.bizimpl.UserBIZImpl;
import com.qianfeng.entity.User;

public class UserDeleteByIDServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		String userid = request.getParameter("userid");
		UserBIZ userBIZ = new UserBIZImpl();
		User user = new User();

		try {
			user.setId(Integer.parseInt(userid));
			userBIZ.delete(user, request);
		} catch (Exception e) {
			try {
				response.getWriter().println("{\"OK\":\"NO\"}");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			// TODO: handle exception
		}
		try {
			response.getWriter().println("{\"OK\":\"OK\"}");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
