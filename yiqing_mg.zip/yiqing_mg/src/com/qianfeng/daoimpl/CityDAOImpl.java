package com.qianfeng.daoimpl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import com.qianfeng.dao.CityDAO;
import com.qianfeng.entity.City;

/**
 * A data access object (DAO) providing persistence and search support for City
 * entities. Transaction control of the save(), update() and delete() operations
 * can directly support Spring container-managed transactions or they can be
 * augmented to handle user-managed Spring transactions. Each of these methods
 * provides additional information for how to configure it for the desired type
 * of transaction control.
 * 
 * @see com.qianfeng.entity.City
 * @author MyEclipse Persistence Tools
 */

public class CityDAOImpl extends BaseHibernateDAO implements CityDAO {
	private static final Log log = LogFactory.getLog(CityDAOImpl.class);
	// property constants
	public static final String CITY_ID = "cityId";
	public static final String CITY = "city";
	public static final String FATHER_ID = "fatherId";
	public static final String INFECT_COUNT = "infectCount";

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.qianfeng.entity.CityDAO#save(com.qianfeng.entity.City)
	 */
	@Override
	public void save(City transientInstance) {
		log.debug("saving City instance");
		try {
			getSession().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.qianfeng.entity.CityDAO#delete(com.qianfeng.entity.City)
	 */
	@Override
	public void delete(City persistentInstance) {
		log.debug("deleting City instance");
		try {
			getSession().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.qianfeng.entity.CityDAO#findById(java.lang.Integer)
	 */
	@Override
	public City findById(java.lang.Integer id) {
		log.debug("getting City instance with id: " + id);
		try {
			City instance = (City) getSession().get("com.qianfeng.entity.City",
					id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.qianfeng.entity.CityDAO#findByExample(com.qianfeng.entity.City)
	 */
	@Override
	public List findByExample(City instance) {
		log.debug("finding City instance by example");
		try {
			List results = getSession()
					.createCriteria("com.qianfeng.entity.City")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.qianfeng.entity.CityDAO#findByProperty(java.lang.String,
	 * java.lang.Object)
	 */
	@Override
	public List findByProperty(String propertyName, Object value) {
		log.debug("finding City instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from City as model where model."
					+ propertyName + "= ?";
			Query queryObject = getSession().createQuery(queryString);
			queryObject.setParameter(0, value);
			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.qianfeng.entity.CityDAO#findByCityId(java.lang.Object)
	 */
	@Override
	public List findByCityId(Object cityId) {
		return findByProperty(CITY_ID, cityId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.qianfeng.entity.CityDAO#findByCity(java.lang.Object)
	 */
	@Override
	public List findByCity(Object city) {
		return findByProperty(CITY, city);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.qianfeng.entity.CityDAO#findByFatherId(java.lang.Object)
	 */
	@Override
	public List findByFatherId(Object fatherId) {
		return findByProperty(FATHER_ID, fatherId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.qianfeng.entity.CityDAO#findByInfectCount(java.lang.Object)
	 */
	@Override
	public List findByInfectCount(Object infectCount) {
		return findByProperty(INFECT_COUNT, infectCount);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.qianfeng.entity.CityDAO#findAll()
	 */
	@Override
	public List findAll() {
		log.debug("finding all City instances");
		try {
			String queryString = "from City";
			Query queryObject = getSession().createQuery(queryString);
			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.qianfeng.entity.CityDAO#merge(com.qianfeng.entity.City)
	 */
	@Override
	public City merge(City detachedInstance) {
		City city = null;
		Transaction transaction = getSession().beginTransaction();
		try {
			transaction.begin();
			city = (City) getSession().merge(detachedInstance);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
			// TODO: handle exception
		} finally {
			getSession().close();
		}
		return city;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.qianfeng.entity.CityDAO#attachDirty(com.qianfeng.entity.City)
	 */
	@Override
	public void attachDirty(City instance) {
		log.debug("attaching dirty City instance");
		try {
			getSession().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.qianfeng.entity.CityDAO#attachClean(com.qianfeng.entity.City)
	 */
	@Override
	public void attachClean(City instance) {
		log.debug("attaching clean City instance");
		try {
			getSession().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	@Override
	public BigDecimal getTotalCount() {
		// TODO Auto-generated method stub
		BigDecimal totalCount = new BigDecimal(352);
		try {
			long totalCount3 = (Long) getSession().createQuery(
					"select count(*) from City").uniqueResult();
			totalCount = new BigDecimal(totalCount3);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return totalCount;
	}

	@Override
	public List<City> findUserListByPage(BigDecimal beginPageCount,
			BigDecimal pageCount) {
		// TODO Auto-generated method stub
		List<City> userList = new ArrayList<City>();
		try {
			Query query = getSession().createQuery("from City");
			query.setFirstResult(beginPageCount.intValue());
			query.setMaxResults(pageCount.intValue());
			userList = query.list();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			getSession().close();
		}
		// TODO Auto-generated method stub
		return userList;
	}

	@Override
	public List<City> searchCity(String hql, Map<String, Object> city) {
		// TODO Auto-generated method stub
		List<City> cityList = new ArrayList<City>();
		try {
			cityList = getSession().createQuery(hql).setProperties(city).list();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return cityList;
	}

}