package com.qianfeng.servlet;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qianfeng.biz.CityBIZ;
import com.qianfeng.bizimpl.CityBIZImpl;
import com.qianfeng.entity.City;

public class CityUpdateServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");
		String cityname = request.getParameter("city");
		String infectCount = request.getParameter("infectCount");
		CityBIZ cityBIZ = new CityBIZImpl();
		City city = new City();
		try {
			city.setId(Integer.parseInt(id));
			city.setInfectCount(Integer.parseInt(infectCount));
			cityBIZ.merge(city);
			// cityBIZ.update(request, response);

			response.sendRedirect("MapDataGridServlet?pageindex="
					+ request.getParameter("pageindex") + "");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			try {
				response.sendRedirect("userUpdate.jsp?id=" + id + "&city="
						+ cityname + "&infectCount" + infectCount + "");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
}
