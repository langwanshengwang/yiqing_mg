package com.qianfeng.vo;

import java.math.BigDecimal;

public class PageVO<T> {
	private T data;
	private BigDecimal pageIndex;
	private BigDecimal pageCount;
	private BigDecimal totalCount;
	private BigDecimal endPage;

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public BigDecimal getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(BigDecimal pageIndex) {
		this.pageIndex = pageIndex;
	}

	public BigDecimal getPageCount() {
		return pageCount;
	}

	public void setPageCount(BigDecimal pageCount) {
		this.pageCount = pageCount;
	}

	public BigDecimal getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(BigDecimal totalCount) {
		this.totalCount = totalCount;
	}

	public BigDecimal getEndPage() {
		return endPage;
	}

	public void setEndPage(BigDecimal endPage) {
		this.endPage = endPage;
	}

}
