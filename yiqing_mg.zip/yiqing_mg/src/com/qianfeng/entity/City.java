package com.qianfeng.entity;

/**
 * City entity. @author MyEclipse Persistence Tools
 */

public class City implements java.io.Serializable {

	// Fields

	private Integer id;
	private Integer cityId;
	private String city;
	private Integer fatherId;
	private Integer infectCount;

	// Constructors

	/** default constructor */
	public City() {
	}

	/** minimal constructor */
	public City(Integer cityId, String city, Integer fatherId) {
		this.cityId = cityId;
		this.city = city;
		this.fatherId = fatherId;
	}

	/** full constructor */
	public City(Integer cityId, String city, Integer fatherId,
			Integer infectCount) {
		this.cityId = cityId;
		this.city = city;
		this.fatherId = fatherId;
		this.infectCount = infectCount;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCityId() {
		return this.cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Integer getFatherId() {
		return this.fatherId;
	}

	public void setFatherId(Integer fatherId) {
		this.fatherId = fatherId;
	}

	public Integer getInfectCount() {
		return this.infectCount;
	}

	public void setInfectCount(Integer infectCount) {
		this.infectCount = infectCount;
	}

}