package com.qianfeng.biz;

import java.util.List;

import com.qianfeng.entity.JsonRootBean;
import com.qianfeng.entity.Province;

public interface ProvinceBIZ {

	void save(Province transientInstance);

	void delete(Province persistentInstance);

	Province findById(java.lang.Integer id);

	List findByExample(Province instance);

	List findByProperty(String propertyName, Object value);

	List findByProvince(Object province);

	List<JsonRootBean> findAll();

	Province merge(Province detachedInstance);

	void attachDirty(Province instance);

	void attachClean(Province instance);

}