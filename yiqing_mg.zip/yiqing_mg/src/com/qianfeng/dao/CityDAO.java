package com.qianfeng.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.qianfeng.entity.City;

public interface CityDAO {

	void save(City transientInstance);

	void delete(City persistentInstance);

	City findById(java.lang.Integer id);

	List findByExample(City instance);

	List findByProperty(String propertyName, Object value);

	List findByCityId(Object cityId);

	List findByCity(Object city);

	List findByFatherId(Object fatherId);

	List findByInfectCount(Object infectCount);

	List findAll();

	City merge(City detachedInstance);

	void attachDirty(City instance);

	void attachClean(City instance);

	BigDecimal getTotalCount();

	List<City> findUserListByPage(BigDecimal beginPageCount,
			BigDecimal pageCount);

	List<City> searchCity(String hql, Map<String, Object> city);
}