package com.qianfeng.servlet;

import java.math.BigDecimal;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qianfeng.biz.UserBIZ;
import com.qianfeng.bizimpl.UserBIZImpl;
import com.qianfeng.entity.User;
import com.qianfeng.vo.PageVO;

public class UserListByPageServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		String pageIndex = request.getParameter("pageindex") == null ? "1"
				: request.getParameter("pageindex");
		String pageCount = request.getParameter("pagenumber") == null ? "10"
				: request.getParameter("pagenumber");
		UserBIZ userBIZ = new UserBIZImpl();
		PageVO<List<User>> pageVO = new PageVO<List<User>>();
		try {
			BigDecimal totalCount = userBIZ.getTotalCount();
			List<User> userList = userBIZ.findUserListByPage(new BigDecimal(
					pageIndex), new BigDecimal(pageCount));
			pageVO.setData(userList);
			pageVO.setPageIndex(new BigDecimal(pageIndex));
			pageVO.setPageCount(new BigDecimal(pageCount));
			pageVO.setTotalCount(totalCount);
			pageVO.setEndPage(totalCount.divide(new BigDecimal(pageCount), 0,
					BigDecimal.ROUND_UP));

			request.setAttribute("pageVO", pageVO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			request.getRequestDispatcher("userList.jsp").forward(request,
					response);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
