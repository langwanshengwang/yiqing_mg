package com.qianfeng.bizimpl;

import java.io.File;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jspsmart.upload.SmartUpload;
import com.qianfeng.biz.UserBIZ;
import com.qianfeng.dao.UserDAO;
import com.qianfeng.daoimpl.UserDAOImpl;
import com.qianfeng.entity.User;
import com.qianfeng.enums.UserEnum;

public class UserBIZImpl implements UserBIZ {

	UserDAO userDAO = new UserDAOImpl();

	@Override
	public void save(User transientInstance) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(User persistentInstance, HttpServletRequest request)
			throws Exception {
		// TODO Auto-generated method stub
		User user = userDAO.findById(persistentInstance.getId());
		// File file = new File(request.getRealPath("upload") + File.separator
		// + user.getIamgepath());
		File file = new File(request.getRealPath("upload") + File.separator);
		file.delete();
		try {
			userDAO.delete(persistentInstance);
		} catch (Exception e) {
			// TODO: handle exception
			throw e;
		}

	}

	@Override
	public User findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findByExample(User instance) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findByProperty(String propertyName, Object value) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findByUsername(Object username) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findByPassword(Object password) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findByEamil(Object eamil) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User merge(User detachedInstance) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void attachDirty(User instance) {
		// TODO Auto-generated method stub

	}

	@Override
	public void attachClean(User instance) {
		// TODO Auto-generated method stub

	}

	@Override
	public String login(String email, String password, String valitCode,
			String sysCode, HttpServletRequest request) {
		if (valitCode == null || valitCode.equals("")) {
			return UserEnum.VALIDATE_CODE_IS_FAIL.getValue();
		}
		if (!valitCode.equals(sysCode)) {
			return UserEnum.VALIDATE_CODE_IS_FAIL.getValue();
		}
		if (email == null || email.equals("")) {
			return UserEnum.EMAIL_IS_EMPTY.getValue();
		}
		if (password == null || password.equals("")) {
			return UserEnum.PASSWORD_IS_EMPTY.getValue();
		}
		User user = userDAO.login(email, password);
		if (user == null) {
			return UserEnum.USERNAME_OR_PASSWORD_FAIL.getValue();
		}
		request.getSession().setAttribute("user", user);
		return UserEnum.LOGIN_SUCCESS.getValue();
	}

	@Override
	public BigDecimal getTotalCount() {
		// TODO Auto-generated method stub
		return userDAO.getTotalCount();
	}

	@Override
	public List<User> findUserListByPage(BigDecimal pageIndex,
			BigDecimal pageCount) {
		// TODO Auto-generated method stub
		BigDecimal beginPageCount = pageIndex.subtract(new BigDecimal(1))
				.multiply(pageCount);
		return userDAO.findUserListByPage(beginPageCount, pageCount);
	}

	@Override
	public String update(HttpServletRequest request,
			HttpServletResponse response, ServletConfig servletConfig) {
		// TODO Auto-generated method stub
		SmartUpload smartUpload = new SmartUpload();
		try {
			smartUpload.initialize(servletConfig, request, response);
			smartUpload.setMaxFileSize(1024 * 1024 * 10);

			smartUpload.upload();
			String userid = smartUpload.getRequest().getParameter("userid");
			String username = smartUpload.getRequest().getParameter("username");
			String email = smartUpload.getRequest().getParameter("email");
			if (username == null || username.equals("")) {
				return UserEnum.USERNAME_IS_EMPTY.getValue();
			}
			String password = smartUpload.getRequest().getParameter("password");
			if (password == null | password.equals("")) {
				return UserEnum.PASSWORD_IS_EMPTY.getValue();
			}

			User user = userDAO.findById(Integer.parseInt(userid));
			user.setUsername(username);
			user.setPassword(password);
			if (smartUpload.getFiles().getSize() > 0) {
				String fileEXT = smartUpload.getFiles().getFile(0).getFileExt();
				String fileName = new SimpleDateFormat("yyyyMMddHHmmssSS")
						.format(new Date());
				fileName = fileName + "." + fileEXT;
				try {
					user.setIamgepath(fileName);
					userDAO.update(user);
					smartUpload
							.getFiles()
							.getFile(0)
							.saveAs(request.getRealPath("upload")
									+ java.io.File.separator + fileName);

				} catch (Exception e) {
					e.printStackTrace();
					return UserEnum.UPDATE_FAIL.getValue();
					// TODO: handle exception

				}
			} else {

				try {
					userDAO.update(user);

				} catch (Exception e) {
					e.printStackTrace();
					return UserEnum.UPDATE_FAIL.getValue();
					// TODO: handle exception
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return UserEnum.UPDATE_FAIL.getValue();
		}

		return UserEnum.UPDATE_SUCCESS.getValue();
	}

	@Override
	public List<User> searchUser(String username, String email) {
		// TODO Auto-generated method stub
		StringBuilder hql = new StringBuilder("from User as us where 1=1");
		Map<String, Object> param = new HashMap<String, Object>();
		if (username != null && !username.equals("")) {
			hql.append(" and us.username like :username");
			param.put("username", "%" + username + "%");
		}
		if (email != null && !email.equals("")) {
			hql.append(" and us.email like :email");
			param.put("email", "%" + email + "%");
		}
		return userDAO.searchUser(hql.toString(), param);
	}

}
