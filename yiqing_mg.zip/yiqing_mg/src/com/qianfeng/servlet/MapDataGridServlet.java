package com.qianfeng.servlet;

import java.math.BigDecimal;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qianfeng.biz.CityBIZ;
import com.qianfeng.bizimpl.CityBIZImpl;
import com.qianfeng.entity.City;
import com.qianfeng.vo.PageVO;

public class MapDataGridServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		String pageIndex = request.getParameter("pageindex") == null ? "1"
				: request.getParameter("pageindex");
		String pageCount = request.getParameter("pagenumber") == null ? "10"
				: request.getParameter("pagenumber");
		CityBIZ cityBIZ = new CityBIZImpl();
		PageVO<List<City>> pageVO = new PageVO<List<City>>();
		try {
			BigDecimal totalCount = cityBIZ.getTotalCount();
			List<City> userList = cityBIZ.findUserListByPage(new BigDecimal(
					pageIndex), new BigDecimal(pageCount));
			pageVO.setData(userList);
			pageVO.setPageIndex(new BigDecimal(pageIndex));
			pageVO.setPageCount(new BigDecimal(pageCount));
			pageVO.setTotalCount(totalCount);
			pageVO.setEndPage(totalCount.divide(new BigDecimal(pageCount), 0,
					BigDecimal.ROUND_UP));

			request.setAttribute("pageVO", pageVO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			request.getRequestDispatcher("COVID-19MapDataGrid.jsp").forward(
					request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
